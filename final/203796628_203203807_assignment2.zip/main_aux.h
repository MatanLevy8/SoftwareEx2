#ifndef MAIN_AUX_H_
#define MAIN_AUX_H_

/**
 * The method used in order to start the process.
 */
void start();

#endif

