#include "main_aux.h"

/*
 * The main method, used to call the start method at
 * the main_aux which performs the program's logic
 */
int main()
{
	start();
	return 0;
}

